Unit 4 Body Language 优化课件 · 旧版 PPT

Body_Language.ppt 是真正的 PowerPoint 97–2003 .ppt 文件，共21页。
请将本压缩包完整解压后使用，不要直接在压缩包中打开课件。

旧版导出不能保留原课件的嵌入媒体；原音视频未删减，已逐字节保存在media文件夹中：
第6页：media/Slide6_Video.mp4
第7页：media/Slide7_Video.mp4
第8页听力音频：media/Slide8_Audio.mp3

PPT中的媒体图片/图标添加了文件链接；不同PowerPoint或WPS版本可能有兼容或安全提示，课前请检查。
如果链接打不开，可直接打开对应的配套媒体文件播放；不要移动或改名media文件夹。
媒体内容和长度与原文件一致。音视频未嵌入这个旧版PPT文件。
18页含重点/卡片淡入动画，另有页面淡化过渡；旧版软件效果可能有所差异。
开场白与教学提示详见Teaching_Notes.txt及课件备注。
